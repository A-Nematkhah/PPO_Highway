# Changelog

## Unreleased

### Experiment management system (run directories, metadata, reports, CSV exports)
- **Every `python -m eureka.loop` invocation now creates its own numbered
  `runs/run_NNNN/` directory** (`eureka/experiment.py`'s `ExperimentRun`),
  auto-incrementing and never overwriting a previous run.
- **`eureka/run_metadata.py`**: best-effort collection of git commit/branch/
  dirty-flag, Python version, OS, CPU model, core count, and total RAM for
  every run - no new hard dependencies (optional `psutil`, else a
  zero-dependency ctypes/`/proc` fallback), every field degrades to `None`
  rather than aborting the run if it can't be collected.
- **`eureka/csv_export.py`**: `pareto_archive.csv`, `generation_summary.csv`,
  `candidate_metrics.csv` per run.
- **`eureka/report_html.py`**: a self-contained `report.html` per run
  (plots embedded as base64 data URIs) with Experiment Summary, Training
  Summary, per-generation tables, the full Pareto archive with winner
  highlighting, archived reflection prompts, and execution-time breakdown
  (train/eval/LLM time, aggregated straight out of the existing
  `telemetry.jsonl` event stream - no new instrumentation). All
  LLM-adjacent text (reflection prompts) is HTML-escaped before rendering.
- **`logging_utils.py`**: added `print_generation_table` (per-generation
  Pareto front + winner + reason, printed at the end of every generation)
  and `print_final_results_banner` (end-of-run FINAL RESULTS banner).
- **Architectural constraint preserved deliberately**: candidate reward
  source and training checkpoints stay in their existing shared locations
  (`eureka/candidates/`, `eureka/checkpoints/`) rather than moving into the
  run directory, because `eureka/sandbox.py` derives a candidate's on-disk
  path directly from its dotted module path - moving the live copy would
  require changing sandbox path resolution, which is out of scope. The run
  directory gets **archival copies** instead (`reward_candidates/`,
  `checkpoints/`, `final_reward.py`), while the live copies the search
  actually reads from are untouched.
- `eureka/llm_reward_designer.py`: hoisted the local `roles` tuple in
  `generate_candidates()` to a module-level `REFLECTION_TARGET_ROLES`
  constant (pure extraction, zero behavior change - verified via the
  existing test suite) so loop.py can archive the exact same reflection
  prompts actually used for a generation without duplicating the literal
  tuple or touching candidate-generation logic itself.
- `eureka/loop.py`: `_finalize_run` now accepts explicit `log_path`/
  `plots_dir` (instead of reading fixed module constants) and returns the
  confirmed final archive/representative, feeding the new
  `_finalize_experiment_artifacts` step (checkpoint/reward archiving, CSV
  export, HTML report, final console banner, metadata.json update with
  execution time).
- Updated 5 existing test call sites (`test_component_sidecar.py`,
  `test_human_seed.py`, `test_integration_loop.py`) that previously
  monkeypatched `loop.LOG_PATH` to a fixed path - these now expect the new
  default `runs/run_0001/...` location, since per-run directories are the
  new default behavior, not opt-in.
- Added `eureka/tests/test_experiment.py`, `test_run_metadata.py`,
  `test_csv_export.py`, `test_report_html.py`, and new console-table tests
  in `test_observability.py` (48 new tests total). Verified end-to-end via
  a full manual `loop.main()` invocation with every artifact inspected by
  hand, not just unit-tested in isolation.

### Software-quality audit: regression fixes, test-suite reliability, orchestration refactor
- **Fixed a real regression**: the previous commit had reverted
  `eureka/train_candidate.py`, silently deleting `component_sidecar_path()`
  and `_remove_stale_component_sidecar()` that an earlier commit had added.
  `eureka/tests/test_component_sidecar.py` still referenced both, which
  made the entire file fail to *collect* (not just fail) - meaning it and
  every test after it in that run were silently skipped by anyone not
  passing `--continue-on-collection-errors`. Both functions restored;
  `loop.py`'s two other inline copies of the same sidecar-path convention
  now call the shared function instead of duplicating it.
- **Fixed a real bug surfaced by restoring the test above**: a corrupt or
  unreadable component-history sidecar (purely diagnostic LLM-reflection
  data) was being read inside the *same* `try/except` that wraps
  `train_candidate()` itself, in both the sequential and
  `ProcessPoolExecutor` training paths in `loop.py`. A malformed sidecar
  therefore rejected an otherwise successfully-trained-and-checkpointed
  candidate. Sidecar loading is now its own fault-tolerant helper
  (`_load_component_history`) that degrades to "no component history" and
  logs a warning, and can never discard a good checkpoint.
- **Fixed a genuine test-isolation bug** (not a product bug) in
  `test_shaping_call.py`: two tests called `sc.logger.addHandler(caplog.handler)`
  *in addition to* `caplog.at_level(level, logger="eureka.shaping_call")`,
  which already attaches that same handler (pytest's documented workaround
  for loggers with `propagate=False`, which `eureka.logging_utils.setup_logging()`
  sets). Registering the handler twice double-counted every log record,
  causing intermittent, order-dependent assertion failures on record counts.
  Removed the redundant manual registration; the two tests are now
  deterministic under repeated and isolated runs.
- **Refactored `eureka/loop.py`'s `main()`** from ~314 lines down to ~90 by
  extracting `_record_empty_generation`, `_record_generation_with_no_survivors`,
  `_finalize_successful_generation` (the single largest block, ~115 lines:
  Pareto ranking, second-seed screening, archive update, log/telemetry
  emission), and `_finalize_run` (post-loop confirmation, plotting, final
  summary). Pure extraction - verified byte-for-byte identical behavior via
  the full unit suite plus the mocked-LLM end-to-end integration test both
  before and after.
- **Added `eureka/tests/test_evaluate_cli.py`** (32 tests): the new
  `evaluate_cli.py` CLI tool had zero test coverage, which would have
  dropped the CI coverage gate from passing to failing (69% vs the 80%
  `fail_under` in `.coveragerc`). Covers candidate-name resolution,
  discovery, all CLI validation branches, and per-candidate orchestration
  (skip/success/failure/`--render-only` paths) via mocking
  `evaluate_candidate()` / `render_candidate()` at the boundary - the
  render internals that need a real torch model, a real highway-env
  instance, and (for `--render-live`) a real display are left uncovered by
  unit tests for the same reason `loop.py`, `train_candidate.py`,
  `smoke_test.py`, and `env_factory.py` already are. Coverage: 68.7% → 86.9%.
- Net result: the full non-integration suite (150 tests) now passes
  consistently, with zero known-flaky or known-broken tests, across
  repeated runs.

### Documentation audit + root README
- Added root `README.md` and `docs/DOC_AUDIT.md` reconciling code/docs drift.
- Rewrote stale architecture claims (removed modules still documented as live).
- **Follow-up to "EUREKA-only cleanup":** `train.py`, `evaluate.py`, and
  `llm_judge.py` remain deleted, but `config.USE_LLM_JUDGE` /
  `env_utils._EnvFactory` / `RewardShapingWrapper` still retain judge hooks that
  would `ImportError` if enabled — comments now warn; hooks were not deleted.

### Pareto selection defaults + quieter crash_rate estimates
- Default `MULTI_OBJECTIVE_MODE` is now `"pareto"` so survivor selection and LLM
  reflection elites come from the live epsilon/NSGA-II-lite archive (legacy
  `compute_fitness` stays diagnostic-only).
- Default `N_EVAL_EPISODES` raised from 10 to 30 (~3.3% crash_rate granularity).
- Default `CONFIRMATION_SEEDS = (10000, 20000)` re-checks rank-0 finalists before
  the final archive is reported.
- Integration e2e test now pins `MULTI_OBJECTIVE_MODE="shadow"` and empty
  confirmation seeds so it stays independent of production defaults.

### Shaping executor leak recovery (`eureka/shaping_call.py`)
- Detect when timed-out `shaping_reward()` calls leak all workers in the
  shared `ThreadPoolExecutor` and replace the pool with a fresh executor
  instead of silently degrading every subsequent call to `(0.0, {})`.
- Log warning events for per-call timeouts (`shaping_call_timeout`) and
  executor replacement (`shaping_executor_replaced`) via `logging_utils`.
- Guard leak tracking and replacement with a `threading.Lock` for
  concurrent training/eval callers.
- Add `SHAPING_FN_EXECUTOR_WORKERS` in `eureka_config.py` (default 8).
- Tests in `eureka/tests/test_shaping_call.py` cover saturation recovery
  and concurrent call safety.

### Component-level reward reflection (EUREKA paper Sec 3.3 / Prompt 3)
- shaping_reward() may now optionally return (total: float, components:
  dict[str, float]) instead of a bare float, mirroring the EUREKA
  paper's reward_components output format. Backward compatible: bare
  float returns still work unchanged.
- eureka/sandbox.py: added normalize_shaping_output() to unify both
  return forms with graceful degradation on malformed output.
- eureka/train_candidate.py: accumulates per-component rolling-window
  snapshots during training, written to a checkpoint sidecar JSON file.
- eureka/evaluate_candidate.py: reports component_means alongside
  existing crash_rate/mean_speed/mean_overtakes/mean_raw_return metrics.
- eureka/reflection.py: includes component means and chronological
  training snapshots in the LLM feedback prompt when available, per
  "Reward reflection enables targeted improvement" (paper Sec 4.3,
  reports 28.6% score drop without this granularity).
- No change to training budget, candidate count, or LLM call count.

### Human reward initialization (EUREKA paper Sec 4.4)
- Added `eureka/human_seed.py`: hand-written shaping_reward ported from
  reward_wrapper.py's TTC penalty + overtake bonus, used as an extra
  generation-0 candidate (not counted against K_CANDIDATES) so its real
  trained metrics seed the Pareto archive/reflection context, per
  "EUREKA can improve and benefit from human reward functions" (Ma et
  al., ICLR 2024). Adds one extra train+eval run, generation 0 only.
  Toggle: `SEED_GENERATION_0_WITH_HUMAN_REWARD` in eureka_config.py.

### Multi-objective Pareto / NSGA-II-lite selection
- Added `eureka/objectives.py`: epsilon-box dominance, nondominated sorting,
  normalized crowding distance, deterministic bounded archive, unweighted knee
  representative, and diverse reflection-elite selection.
- Added `MULTI_OBJECTIVE_MODE`: `shadow` logs Pareto metadata while preserving
  legacy scalar selection; `pareto` makes the cross-generation archive authoritative.
- Candidate logs now include objective vectors, epsilon boxes, Pareto rank,
  crowding distance, archive membership, and scalar/Pareto disagreement.
- Reflection now accepts multiple Pareto elites and schedules balanced, safest,
  fastest-safe, and overtaking-safe LLM mutation targets.
- Optional `CONFIRMATION_SEEDS` retrains rank-zero finalists and rebuilds the
  final archive from aggregate metrics.
- Added objective, confirmation, reflection, and mocked Pareto-loop tests.

### EUREKA-only cleanup (phase 1)
- Removed baseline entrypoints: `train.py`, `evaluate.py`, `llm_judge.py`.
- EUREKA pipeline (`python -m eureka.loop`) unchanged; all 12 tests pass.

### Phase 2 — Reliability, observability, test coverage
- **eureka/logging_utils.py**: structured logging (text or JSON via `EUREKA_LOG_JSON=1`).
- **eureka/telemetry.py**: `eureka_metrics.jsonl` timing/events for plotting.
- **loop.py**, **llm_reward_designer.py**, **train_candidate.py**, **evaluate_candidate.py**:
  migrated from `print` to structured logger + telemetry.
- **Unit tests**: fitness, reflection, `_extract_code`, evaluate_candidate (mocked),
  logging/telemetry.
- **Integration test**: `test_integration_loop.py` — mocked LLM, 512 train steps.
- **CI**: GitHub Actions (`.github/workflows/ci.yml`) + `.coveragerc` (80% on non-loop modules).

### Phase 1 — Sandbox & security hardening
- **eureka/sandbox.py**: AST allowlist (whitelist) gate + restricted `exec()` loader
  shared by smoke test and training-time load (replaces `importlib.import_module`).
- **eureka/env_factory.py** + **evaluate_candidate.py**: load candidates via sandbox.
- **eureka/shaping_call.py**: per-step `shaping_reward()` timeout (`SHAPING_FN_TIMEOUT_S`).
- **eureka/candidate_wrapper.py**: uses timed shaping calls.
- **docs/SECURITY.md**: remaining risks + Phase 3 DSL roadmap.
- **eureka/tests/test_redteam_sandbox.py**: 15 red-team escape payloads (all rejected).
- **eureka/tests/test_sandbox.py**, **test_shaping_call.py**: loader + timeout tests.

### Concurrency, sandbox, reproducibility (Phase 0)
- **env_utils.py**: Worker env init wrapped in try/except; `AsyncVectorEnv` uses
  `poll()` timeouts on all blocking `recv()` calls; failures raise `RuntimeError`
  with module_path/seed context instead of hanging silently.
- **eureka/loop.py**: Training/eval failures (`RuntimeError` from worker env init)
  reject the candidate and continue the search.
- **eureka/smoke_test.py**: Reject all `.format()` calls (runtime dunder bypass);
  POSIX `resource.setrlimit` in probe worker as defense-in-depth.
- **eureka/eureka_config.py**: `candidate_base_seed()` — disjoint seed blocks per
  candidate (`k * EUREKA_N_ENVS`) so sibling candidates no longer share RNG state.

### Security (critical)
- **smoke_test.py**: Removed `_sanitize_candidate_code()` which stripped `import`
  lines before exec but let the raw code through to disk/import. `smoke_test()`
  now validates the **exact** string that `loop.py` writes and `env_factory.py`
  imports: AST rejection first, then an unmodified exec in a **spawn subprocess**
  runtime probe with restricted builtins.
- **env_factory.py**: Training-time code now uses the restricted sandbox loader
  rather than `importlib`; OS-level container isolation remains future work.

### Correctness / maintainability
- **ppo.py**: Removed duplicate dead method `set_learning_rate()`; `set_lr()` kept.
- **reward_wrapper.py**: `_compute_overtake_bonus()` now delegates to shared
  `compute_overtakes()` (same logic as `eureka/candidate_wrapper.py`).
- **smoke_test.py**: Runtime probe varies `n_overtakes` (from `compute_overtakes()`
  plus explicit nonzero probes) so candidates that only work at `n_overtakes == 0`
  are caught.

### Tests
- Added `eureka/tests/test_smoke_test.py` (AST rejection + malicious-code rejection).
- Added `eureka/tests/test_reward_wrapper.py` (shared overtake counting).
